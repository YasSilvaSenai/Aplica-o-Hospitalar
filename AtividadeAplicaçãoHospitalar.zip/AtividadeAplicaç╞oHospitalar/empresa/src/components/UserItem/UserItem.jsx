'use client';

export default function UserItem({ user }) {
  return (
    <div className="card h-100 shadow-sm">
      <div className="card-body d-flex">
        <img src={user.picture.medium} alt={user.name.first} className="rounded-circle me-3" />
        <div>
          <h5>{user.name.first} {user.name.last}</h5>
          <p><strong>Usuário:</strong> {user.login.username}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>Cidade:</strong> {user.location.city}</p>
        </div>
      </div>
    </div>
  );
}
