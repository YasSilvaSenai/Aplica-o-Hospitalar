import React from "react";

const sobre = ({ titulo, descricao, imagemUrl }) => {
  return (
    <main className="container py-5">
      <div className="row align-items-center">
        <div className="col-md-6 mb-4 mb-md-0">
          <h1 className="mb-3">{titulo}</h1>
          <p>{descricao}</p>
        </div>

        <div className="col-md-6 text-center">
          <img
            src={imagemUrl}
            alt={titulo}
            className="img-fluid rounded shadow"
          />
        </div>
      </div>
    </main>
  );
};

export default sobre;
