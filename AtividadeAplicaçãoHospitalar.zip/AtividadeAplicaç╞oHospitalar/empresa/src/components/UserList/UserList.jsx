'use client';
import UserItem from '../UserItem/UserItem';

export default function UserList({ users }) {
  return (
    <div className="row">
      {users.map((user) => (
        <div key={user.login.uuid} className="col-md-6 mb-4">
          <UserItem user={user} />
        </div>
      ))}
    </div>
  );
}
