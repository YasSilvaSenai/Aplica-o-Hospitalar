import Link from "next/link";
import Image from "next/image";

export default function footer() {
    return (
        <>
        <footer className="bg-body-tertiary text-center text-lg-start">
  <div
    className="text-center p-3"
    style={{ backgroundColor: "rgba(0, 0, 0, 0.05)" }}
  >
    © 2025 direitos reservados por: 
    <a className="text-body">
       umbrella
    </a>
  </div>
</footer>

        </>
    )};