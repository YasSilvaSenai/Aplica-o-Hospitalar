'use client';
import { useState } from 'react';
import axios from 'axios';
import UserList from '@/components/UserList/UserList';
import './globals.css';
import sobre from '@/components/sobre/sobre';


export default function Home() {
  const [userCount, setUserCount] = useState(5);  // Contador de usuários
  const [users, setUsers] = useState([]);         // Lista de usuários
  const [loading, setLoading] = useState(false);  // Estado de carregamento

  // Função para buscar os usuários da API
  const fetchUsers = async (count) => {
    setLoading(true);
    try {
      const res = await axios.get(`https://randomuser.me/api/?results=${count}`);
      setUsers(res.data.results);
    } finally {
      setLoading(false);
    }
  };

  // Função para alterar o contador de usuários
  const handleClickContador = (increment) => {
    setUserCount((prev) => {
      const novo = prev + increment;
      if (novo < 5) {
        alert('Mínimo: 5 usuários');
        return 5;
      } else if (novo > 100) {
        alert('Máximo: 100 usuários');
        return 100;
      }
      return novo;
    });
  };

  return (
    <>
      <div className="banner">
        <img src="banner.png" alt="Banner Desktop" className="banner-desktop" />
        <img src="banner_celular.png" alt="Banner Mobile" className="banner-mobile" />
      </div>

     

      <div className="container py-5">
        <h2 className="mb-4">Lista de Profissionais</h2>

        <div className="mb-4 d-flex align-items-center gap-2 flex-wrap">
          <button type="button" onClick={() => handleClickContador(-1)} className="btn btn-danger">-</button>

          <input type="number" value={userCount}  min={5} max={100} onChange={(e) => { let value = Number(e.target.value) || 0;  if (value < 5) value = 5; if (value > 100) value = 100; setUserCount(value);}}
            className="form-control"
            style={{ width: '80px' }}
          />

          <button type="button" onClick={() => handleClickContador(1)} className="btn btn-success">+</button>

          <button
            type="button"
            className="btn btn-primary"
            onClick={() => fetchUsers(userCount)}
          >
            Carregar Médicos
          </button>
        </div>

        {loading ? <p>Carregando, aguarde...</p> : <UserList users={users} />}
      </div>
    </>
  );
}
